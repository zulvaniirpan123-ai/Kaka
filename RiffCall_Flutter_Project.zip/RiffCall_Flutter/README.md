# Riff Call — Flutter Demo UI

Riff Call adalah proyek Flutter demo UI bertema dark untuk aplikasi panggilan.

## Fitur demo
- Beranda dan daftar kontak contoh
- Tampilan panggilan video dan suara (simulasi, bukan koneksi nyata)
- Kontrol mikrofon, kamera, speaker, dan akhiri panggilan (kontrol UI)
- Panel chat selama panggilan
- Chat / daftar percakapan contoh
- Riwayat panggilan dan panggilan grup demo
- Halaman profil dan akun contoh
- Navigasi bawah dan tema dark

## Catatan penting
Versi ini **belum melakukan panggilan video/suara sungguhan**, belum memakai kamera/mikrofon perangkat, belum memiliki backend, autentikasi, atau signaling WebRTC. Data chat dan akun hanya contoh di memori dan tidak tersimpan setelah aplikasi ditutup. Untuk versi produksi, tambahkan backend/auth, database, dan WebRTC/signaling.

## Menjalankan di komputer
1. Pasang Flutter SDK dan Android SDK.
2. Ekstrak ZIP.
3. Di folder proyek jalankan:
   ```bash
   flutter pub get
   flutter run
   ```
4. Untuk APK:
   ```bash
   flutter build apk --release
   ```
   APK biasanya dibuat di `build/app/outputs/flutter-apk/app-release.apk`.

## Build melalui HP Android
Pilihan yang paling mudah adalah memakai IDE/build service berbasis browser yang mendukung Flutter:
1. Unduh ZIP ini ke HP lalu ekstrak, atau unggah ZIP ke repositori Git milikmu.
2. Buka layanan cloud IDE/build yang mendukung Flutter dan Android SDK melalui browser HP.
3. Impor folder proyek, jalankan `flutter pub get`, lalu jalankan `flutter build apk --release`.
4. Unduh artefak `app-release.apk` setelah build selesai.
5. Instal APK hanya jika build berasal dari proyek yang kamu percayai; Android mungkin meminta izin untuk memasang aplikasi dari sumber tersebut.

Catatan: Termux biasa tanpa toolchain Android yang disiapkan tidak otomatis dapat membangun APK. Jika layanan yang dipakai tidak menyediakan Flutter + Android SDK, build tidak akan berhasil. Proyek ini belum menyertakan wrapper Gradle/konfigurasi platform Android yang dihasilkan Flutter; jalankan `flutter create .` di folder proyek setelah ekstrak untuk membuat folder platform standar sebelum build.

## Build APK dari HP dengan GitHub Actions
Workflow build otomatis sudah disertakan di `.github/workflows/android-apk.yml`.

1. Buat repositori GitHub baru dari browser HP.
2. Unggah seluruh isi folder proyek ini ke repositori, termasuk folder `.github/workflows`.
3. Buka tab **Actions**, pilih **Build Riff Call APK**, lalu tekan **Run workflow** (atau tunggu build saat push ke branch `main`).
4. Setelah workflow selesai, buka hasil run dan unduh artifact **riff-call-release-apk**.
5. Ekstrak artifact ZIP untuk memperoleh `app-release.apk`.

Workflow menghasilkan APK debug/release unsigned untuk pengujian lokal. Untuk distribusi publik di Play Store, perlu konfigurasi signing key dan pengujian tambahan.
